const tvMazeApiData = require("./searchshows");

module.exports = { searchshows: tvMazeApiData };

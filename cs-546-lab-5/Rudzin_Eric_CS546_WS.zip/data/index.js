const userApiData = require("./userApi");

module.exports = { userApi: userApiData };
